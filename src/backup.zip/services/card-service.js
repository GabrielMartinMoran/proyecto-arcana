/**
 * CardService - Load and query ARCANA cards from config and cache
 */
import StorageUtils from "../utils/storage-utils.js";

const STORAGE_KEY = "cards-cache";
const CONFIG_PATH = "config/cards-config.json";

let cachedCards = null;

function normalizeCard(raw) {
    const card = { ...raw };
    card.id = card.id || `${(card.name || "").toLowerCase().replace(/\s+/g, "-")}-${card.level || "n"}`;
    card.name = card.name || "Unknown";
    card.level = Number(card.level) || 1;
    card.type = card.type || "Accionable"; // or "De Efecto"
    card.attribute = card.attribute || null; // Cuerpo, Agilidad, etc
    // Backward compatibility: map sintonia -> arquetipo
    card.arquetipo = card.arquetipo || card.sintonia || null;
    card.requirements = Array.isArray(card.requirements) ? card.requirements : (card.requirements ? [card.requirements] : []);
    card.description = card.description || "No description";
    card.cooldown = card.cooldown || null;
    return card;
}

function applyFilters(cards, criteria) {
    if (!criteria) return cards;
    const text = (criteria.text || "").trim().toLowerCase();
    const levels = new Set(criteria.levels || []);
    const types = new Set(criteria.types || []);
    const attributes = new Set(criteria.attributes || []);
    const arquetipos = new Set(criteria.arquetipos || criteria.sintonias || []);

    return cards.filter((card) => {
        if (text && !String(card.name || "").toLowerCase().includes(text)) return false;
        if (levels.size && !levels.has(Number(card.level))) return false;
        if (types.size && !types.has(card.type)) return false;
        if (attributes.size && !attributes.has(card.attribute)) return false;
        if (arquetipos.size && !arquetipos.has(card.arquetipo)) return false;
        return true;
    });
}

const CardService = {
    /** Load cards from config and local cache */
    async loadAll({ force = false } = {}) {
        if (!force && Array.isArray(cachedCards)) return cachedCards;

        try {
            const response = await fetch(CONFIG_PATH, { cache: "no-store" });
            if (!response.ok) throw new Error(`Failed to fetch cards config: ${response.status}`);
            const json = await response.json();
            const fromConfig = Array.isArray(json?.cards) ? json.cards : [];

            const fromLocal = StorageUtils.load(STORAGE_KEY, []);
            const merged = [...fromConfig, ...fromLocal].map(normalizeCard);

            cachedCards = merged;
            return cachedCards;
        } catch (error) {
            console.error("CardService.loadAll error:", error);
            cachedCards = [];
            return cachedCards;
        }
    },

    /** Get cached cards (may be null before load) */
    getCached() { return cachedCards; },

    /** Add a custom card and persist */
    addCard(card) {
        const custom = StorageUtils.load(STORAGE_KEY, []);
        const normalized = normalizeCard(card);
        custom.push(normalized);
        StorageUtils.save(STORAGE_KEY, custom);
        if (Array.isArray(cachedCards)) cachedCards.push(normalized);
        return normalized;
    },

    /** Filter cards using criteria */
    filter(cards, criteria) { return applyFilters(cards, criteria); },

    /** Get unique values for facets (attributes, sintonias, types, levels) */
    getFacets(cards) {
        const attr = new Set();
        const arq = new Set();
        const types = new Set();
        const levels = new Set();
        for (const c of cards) {
            if (c.attribute) attr.add(c.attribute);
            if (c.arquetipo) arq.add(c.arquetipo);
            if (c.type) types.add(c.type);
            if (c.level) levels.add(Number(c.level));
        }
        return {
            attributes: Array.from(attr).sort(),
            arquetipos: Array.from(arq).sort(),
            types: Array.from(types).sort(),
            levels: Array.from(levels).sort((a, b) => a - b)
        };
    }
};

export default CardService;


