const html = window.html || String.raw;
/**
 * FiltersComponent - Text search and facets filters
 * @param {HTMLElement} container
 * @param {{ facets: {attributes:string[], arquetipos:string[], types:string[], levels:number[]}, value?: any, onChange?: (value:any)=>void, onClear?: ()=>void }} props
 */
const FiltersComponent = (container, props = {}) => {
    let state = {
        facets: props.facets || { attributes: [], arquetipos: [], types: ["Accionable","De Efecto"], levels: [1,2,3,4,5] },
        value: props.value || { text: "", levels: [], types: [], attributes: [], arquetipos: [] },
        onChange: typeof props.onChange === "function" ? props.onChange : () => {},
        onClear: typeof props.onClear === "function" ? props.onClear : () => {}
    };

    const renderOptions = (items, placeholder) => [html`<option value="">${placeholder}</option>`]
        .concat(items.map((v) => html`<option value="${v}">${v}</option>`)).join("");

    const render = () => html`
        <div class="filters-panel">
            <div class="filters-block filters-block--search">
                <input id="search" class="filters-input" type="text" placeholder="Search by name" value="${state.value.text || ''}" />
            </div>
            <div class="filters-block filters-block--levels">
                <div class="filters-label">Levels</div>
                <div class="filters-list">
                    ${state.facets.levels.map(l => html`<label class="filters-check"><input type="checkbox" name="level" value="${l}" ${state.value.levels?.includes(l) ? 'checked' : ''}/> ${l}</label>`).join('')}
                </div>
            </div>
            <div class="filters-block filters-block--type">
                <div class="filters-label">Type</div>
                <div class="filters-list">
                    ${state.facets.types.map(t => html`<label class="filters-check"><input type="checkbox" name="type" value="${t}" ${state.value.types?.includes(t) ? 'checked' : ''}/> ${t}</label>`).join('')}
                </div>
            </div>
            <div class="filters-block filters-block--attr">
                <label class="filters-label" for="attr">Attribute</label>
                <select id="attr" class="filters-input">
                    ${renderOptions(state.facets.attributes, 'Any attribute')}
                </select>
            </div>
            <div class="filters-block filters-block--sint">
                <label class="filters-label" for="sint">Arquetipo</label>
                <select id="sint" class="filters-input">
                    ${renderOptions(state.facets.arquetipos, 'Any arquetipo')}
                </select>
            </div>
            <div class="filters-block filters-block--clear">
                <button class="button" data-action="clear">Clear</button>
            </div>
        </div>
    `;

    const bindEvents = () => {
        const search = container.querySelector('#search');
        const attr = container.querySelector('#attr');
        const sint = container.querySelector('#sint');
        const clear = container.querySelector('[data-action="clear"]');
        const levelChecks = container.querySelectorAll('input[name="level"]');
        const typeChecks = container.querySelectorAll('input[name="type"]');

        const emit = () => state.onChange({ ...state.value });

        let debTimer = null;
        const debounced = (fn) => {
            clearTimeout(debTimer); debTimer = setTimeout(fn, 180);
        };

        if (search) search.addEventListener('input', (e) => { state.value.text = e.target.value; debounced(emit); });
        if (attr) attr.addEventListener('change', (e) => {
            const v = e.target.value; 
            state.value.attributes = v ? [v] : []; emit();
        });
        if (sint) sint.addEventListener('change', (e) => {
            const v = e.target.value; 
            state.value.arquetipos = v ? [v] : []; emit();
        });
        if (clear) clear.addEventListener('click', () => { state.value = { text: '', levels: [], types: [], attributes: [], arquetipos: [] }; state.onClear(); });
        levelChecks.forEach(ch => ch.addEventListener('change', (e) => {
            const v = Number(e.target.value);
            if (e.target.checked && !state.value.levels.includes(v)) state.value.levels.push(v);
            if (!e.target.checked) state.value.levels = state.value.levels.filter(x => x !== v);
            emit();
        }));
        typeChecks.forEach(ch => ch.addEventListener('change', (e) => {
            const v = e.target.value;
            if (e.target.checked && !state.value.types.includes(v)) state.value.types.push(v);
            if (!e.target.checked) state.value.types = state.value.types.filter(x => x !== v);
            emit();
        }));
    };

    const setState = (partial) => {
        state = { ...state, ...partial };
        container.innerHTML = render();
        bindEvents();
    };

    const loadStyles = () => {
        const href = './src/components/FiltersComponent/FiltersComponent.css';
        if (![...document.querySelectorAll('link[rel="stylesheet"]')].some(l => l.getAttribute('href') === href)) {
            const link = document.createElement('link');
            link.rel = 'stylesheet';
            link.href = href;
            document.head.appendChild(link);
        }
    };

    return { init: () => { loadStyles(); setState({}); }, setState };
};

export default FiltersComponent;


