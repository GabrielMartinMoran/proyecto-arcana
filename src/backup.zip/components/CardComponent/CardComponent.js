const html = window.html || String.raw;
/**
 * CardComponent - Compact card preview item
 * @param {HTMLElement} container
 * @param {{ card: any, onClick?: (card:any)=>void, actionsRenderer?: (card:any)=>string }} props
 */
const CardComponent = (container, props = {}) => {
    let state = {
        card: props.card || null,
        onClick: typeof props.onClick === "function" ? props.onClick : () => {},
        actionsRenderer: typeof props.actionsRenderer === "function" ? props.actionsRenderer : null
    };

    const getAccentForAttribute = (attr) => {
        switch ((attr || "").toLowerCase()) {
            case "mente": return "var(--pokemon-blue)";
            case "cuerpo": return "var(--pokemon-red)";
            case "agilidad": return "var(--pokemon-yellow)";
            case "instinto": return "var(--pokemon-green)";
            case "presencia": return "var(--pokemon-purple, var(--pokemon-blue))";
            default: return "var(--pokemon-blue)";
        }
    };

    const loadStyles = () => {
        const href = './src/components/CardComponent/CardComponent.css';
        if (![...document.querySelectorAll('link[rel="stylesheet"]')].some(l => l.getAttribute('href') === href)) {
            const link = document.createElement('link');
            link.rel = 'stylesheet';
            link.href = href;
            document.head.appendChild(link);
        }
    };

    const render = () => {
        const c = state.card;
        if (!c) return html`<div class="empty-state">No card</div>`;
        const accent = getAccentForAttribute(c.attribute);
        return html`
            <div class="arcana-card" data-id="${c.id}" data-attr="${c.attribute || ''}" data-type="${c.type || ''}" style="--accent: ${accent}">
                <div class="card-inner">
                    <div class="card-header">
                        <h4 class="card-name">${c.name}</h4>
                        <div class="card-meta">
                            <span class="level-badge">Lv ${c.level}</span>
                            <span class="type-badge">${c.type}</span>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="card-description">${c.description}</div>
                    </div>
                    <div class="card-footer">
                        <div class="card-badges">
                            ${c.attribute ? html`<span class="chip">Atributo: ${c.attribute}</span>` : ''}
                            ${c.arquetipo ? html`<span class="chip">Arquetipo: ${c.arquetipo}</span>` : ''}
                            ${c.cooldown ? html`<span class="chip">Recarga: ${c.cooldown}</span>` : ''}
                        </div>
                        ${(c.requirements && c.requirements.length) ? html`
                            <div class="card-reqs">
                                <span class="req-title">Requirements</span>
                                <div class="req-list">${c.requirements.join(', ')}</div>
                            </div>
                        ` : ''}
                        ${state.actionsRenderer ? html`<div class="card-actions">${state.actionsRenderer(c)}</div>` : ''}
                    </div>
                </div>
            </div>
        `;
    };

    const bindEvents = () => {};

    const setState = (partial) => {
        state = { ...state, ...partial };
        container.innerHTML = render();
        bindEvents();
    };

    return { init: () => { loadStyles(); setState({}); }, setState };
};

export default CardComponent;


